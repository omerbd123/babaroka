import React from 'react'

function IDStep1() {
  return (
    <div>IDStep1</div>
  )
}

export default IDStep1